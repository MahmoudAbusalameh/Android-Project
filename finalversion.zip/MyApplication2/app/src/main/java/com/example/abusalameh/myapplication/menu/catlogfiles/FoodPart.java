package com.example.abusalameh.myapplication.menu.catlogfiles;
import java.io.Serializable;


public class FoodPart implements Serializable {
    public String name = "";
    public String price = "0";
}