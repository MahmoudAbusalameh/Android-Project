package com.example.abusalameh.myapplication.menu.catlogfiles;

import java.io.Serializable;


public class CuponesPart implements Serializable {
    public String name = "";
    public String price = "0";
}