package com.example.abusalameh.myapplication.menu.catlogfiles;
import java.io.Serializable;


public class NonFoodPart implements Serializable {
    public String name = "";
    public String price = "0";
}