package com.example.abusalameh.myapplication.menu.catlogfiles;

import java.io.Serializable;

public class MeatPart implements Serializable {
    public String name = "";
    public String price = "0";
}
